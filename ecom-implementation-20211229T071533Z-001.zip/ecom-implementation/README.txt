First start the Apache server: 
    sudo systemctl start httpd.service