<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
<!-- Font Awesome Kit -->
<script src="https://kit.fontawesome.com/1fb1fb2be8.js" crossorigin="anonymous"></script>
<!-- Paypal -->
<script src="https://www.paypal.com/sdk/js?client-id=AQX1iIXOtGV2UwEYF307-7fqPGSlECr0OKnUdYy_M1Ml0YZjDU2nzJIYdlKi6_hCn8MBxjEW1pGFGK3H&components=buttons&enable-funding=venmo&currency=USD" data-sdk-integration-source="button-factory"></script>
<!-- Custom JS file -->
<script src="../../src.js"></script>


<script src="../../assets/js/util.js"></script> <!-- util functions included in the CodyHouse framework -->
<script src="../../assets/js/main.js"></script> 

<script src='../../js/jquery.js'></script>
<script src='../../js/plugins.js'></script>
<script src='../../js/scripts.js'></script>
<script src='../../js/masonry.pkgd.min.js'></script>